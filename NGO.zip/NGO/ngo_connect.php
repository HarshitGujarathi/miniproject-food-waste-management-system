<?php
    $con = mysqli_connect('localhost','root','','miniproject');  
    $uname =$_POST['uname'];  
    $address = $_POST['address'];
    $Ngo_contact = $_POST['Ngo_contact'];
    $email = $_POST['email'];
    $psw = $_POST['password'];
    $pswconfirm = $_POST['pswconfirm'];
    $sector = $_POST['sector'];
    $sql = "INSERT INTO `ngo_registertable`(`ngo_id`, `uname`, `address`, `contact`, `email`, `password`, `confirm_password`, `sector`) VALUES (0,'$uname','$address','$Ngo_contact','$email','$psw','$pswconfirm','$sector')";
    $result = $con->query($sql);  
    if($result) 
        echo "$uname Record successfully added $email and its status is :  ";  
    else
            echo "Querry"; 
?>
 
