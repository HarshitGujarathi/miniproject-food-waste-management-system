<?php
    $con = mysqli_connect('localhost','root','','miniproject');  
    if($con)
        echo"connection successful";
    $name =$_POST['name'];  
    $phoneno = $_POST['phoneno'];
      $address = $_POST['address'];
    $ds = $_POST['ds'];
    $vehicle_type = $_POST['vehicle_type'];
    $vn = $_POST['vn'];
   $sql = "INSERT INTO `service_provider`( `name`, `phoneno`, `address`, `ds`, `vehicle_type`, `vn`) VALUES ('$name','$phoneno','$address','$ds','$vehicle_type','$vn')"; 
   $result = $con->query($sql);  
    if($result) 
        echo "$name Record successfully added '\n'and its status is :  $ds ";   
?>
